<?php
require_once __DIR__ . '/includes/functions.php';
$sent = false;
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $message = trim($_POST['message'] ?? '');
    if (!$name || !$email || !$message) {
        $error = 'Please fill in all fields.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email.';
    } else {
        // In a real app you'd send mail. Here we just acknowledge.
        $sent = true;
    }
}
$page = ['title' => 'Contact — Damentracht', 'description' => 'Get in touch with the Damentracht team.'];
include __DIR__ . '/includes/header.php';
?>
<div class="container">
  <div class="page-head"><span class="eyebrow">Get in touch</span><h1>Contact us</h1><p>Questions about an order or a product? We'd love to hear from you.</p></div>
</div>
<section class="section" style="padding-top:0">
  <div class="container">
    <div class="checkout-grid">
      <form method="post" class="form-grid">
        <?php if ($error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>
        <?php if ($sent): ?><div class="alert alert-success">Thanks for reaching out — we'll get back to you within 24 hours.</div><?php endif; ?>
        <div class="field"><label for="name">Your name</label><input id="name" name="name" required value="<?= e($_POST['name'] ?? '') ?>"></div>
        <div class="field"><label for="email">Email</label><input type="email" id="email" name="email" required value="<?= e($_POST['email'] ?? '') ?>"></div>
        <div class="field"><label for="message">Message</label><textarea id="message" name="message" required><?= e($_POST['message'] ?? '') ?></textarea></div>
        <button class="btn btn-primary" type="submit">Send message</button>
      </form>
      <aside class="summary-card">
        <h3>Reach us</h3>
        <p style="color:var(--ink-soft);margin-bottom:10px"><?= e(setting('site_address', '')) ?></p>
        <p style="color:var(--ink-soft);margin-bottom:10px"><a href="mailto:<?= e(setting('site_email','')) ?>"><?= e(setting('site_email','')) ?></a></p>
        <p style="color:var(--ink-soft)"><?= e(setting('site_phone','')) ?></p>
      </aside>
    </div>
  </div>
</section>
<?php include __DIR__ . '/includes/footer.php'; ?>
