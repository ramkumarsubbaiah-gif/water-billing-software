# Damentracht — E-Commerce (PHP + MySQL for MAMP)

A complete, industry-standard e-commerce website built with plain PHP and MySQL, designed to run on **MAMP** (Mac/Windows) or **XAMPP**. Includes a storefront and a full admin panel for managing products, categories, orders, and SEO settings.

## Features

**Storefront**
- Premium dark/neutral UI with Fraunces + Inter fonts, animations, hover states
- Home page with hero, featured products, category collections, brand story
- Product detail pages with quantity selector, related products, SEO meta tags + Open Graph
- Category pages with product grids
- Search page
- Session-based cart (add / update qty / remove) with AJAX
- Checkout with COD / UPI / Bank payment options → saves orders to DB
- About + Contact pages
- Fully responsive (mobile → desktop)

**Admin Panel** (`/admin`)
- Secure login (bcrypt password hashing, session-based)
- Dashboard with stats (products, orders, revenue, low-stock alerts)
- Products: create / edit / delete with **image upload** (JPG, PNG, WebP, GIF, SVG)
- Per-product SEO fields (meta title, description, keywords)
- Featured / active toggles
- Categories: add / edit / delete
- Orders: list, view detail, update status (pending → processing → completed → cancelled)
- Site settings: store info, social links, default SEO, currency, announcement bar

**SEO**
- Per-page meta title, description, keywords
- Open Graph + Twitter card tags
- Canonical URLs
- Semantic HTML, `alt` text on images, `loading="lazy"`
- `robots noindex` on admin pages

## Setup with MAMP

### 1. Copy the project to htdocs

Place the `damentracht` folder inside your MAMP `htdocs` directory:

- **Mac:** `/Applications/MAMP/htdocs/damentracht`
- **Windows:** `C:\MAMP\htdocs\damentracht`

### 2. Start MAMP

Open MAMP and click **Start Servers**. Both Apache and MySQL should show green.

### 3. Import the database

1. Go to **http://localhost/phpMyAdmin** (MAMP default: `http://localhost:8888/phpMyAdmin`)
2. Click **Import** → choose `sql/schema.sql` from this project → **Go**
3. This creates the `damentracht` database with all tables + sample data

### 4. Check the MySQL port

Open `includes/config.php` and verify the settings match your MAMP:

```php
define('DB_HOST', '127.0.0.1');
define('DB_PORT', '8889');     // MAMP default MySQL port
define('DB_NAME', 'damentracht');
define('DB_USER', 'root');
define('DB_PASS', 'root');    // '' on Windows, 'root' on Mac MAMP
```

> If your MAMP MySQL runs on port 3306, change `DB_PORT` to `3306`.
> If your MySQL password is empty, set `DB_PASS` to `''`.

### 5. Set the base URL

In `includes/config.php`, set `BASE_URL` to match your folder name:

```php
define('BASE_URL', '/damentracht');  // if project is at htdocs/damentracht
```

### 6. Set folder permissions for uploads

The product image upload folder needs write permission:

```bash
chmod -R 775 uploads/products
```

### 7. Open the site

- **Storefront:** http://localhost:8888/damentracht/  (or `http://localhost/damentracht/` on port 80)
- **Admin:** http://localhost:8888/damentracht/admin/login.php

### 8. Admin login

```
Email:    admin@damentracht.in
Password: admin123
```

> Change this password immediately after first login by updating the `admins` table in phpMyAdmin.

## Project structure

```
damentracht/
├── index.php              # Home page
├── product.php            # Product detail
├── category.php           # Category listing
├── search.php             # Search
├── cart.php               # Cart (handles AJAX too)
├── checkout.php           # Checkout + order placement
├── about.php              # About page
├── contact.php            # Contact page
├── .htaccess
├── sql/
│   └── schema.sql         # Database schema + seed data
├── includes/
│   ├── config.php         # DB + site config
│   ├── db.php             # PDO connection
│   ├── functions.php      # Shared helpers
│   ├── header.php         # Storefront header
│   ├── footer.php         # Storefront footer
│   └── product_card.php   # Reusable product card
├── admin/
│   ├── auth.php           # Auth guard
│   ├── header.php         # Admin layout header
│   ├── footer.php         # Admin layout footer
│   ├── login.php          # Admin login
│   ├── logout.php
│   ├── index.php          # Dashboard
│   ├── products.php       # Product list
│   ├── product-edit.php   # Add/edit product + image upload
│   ├── product-delete.php
│   ├── categories.php     # Category management
│   ├── orders.php         # Order list
│   ├── order-view.php     # Order detail + status update
│   └── settings.php       # Site settings
├── assets/
│   ├── css/style.css      # All styles
│   ├── js/main.js         # Cart + UI interactions
│   └── images/            # Placeholder + OG images
└── uploads/
    └── products/          # Uploaded product images
```

## Customising

- **Add products:** Admin → Add Product → upload image → set SEO fields
- **Add categories:** Admin → Categories
- **Change site name / logo text / social links / SEO defaults:** Admin → Settings
- **Change theme colours:** edit the CSS variables at the top of `assets/css/style.css`

## Tech notes

- No frameworks — plain PHP 7.4+ with PDO (prepared statements throughout)
- MySQL 5.7+ / MariaDB
- Passwords hashed with `password_hash()` (bcrypt)
- No external build step — just PHP + CSS + vanilla JS
- Session-based cart (no login required to shop)

## Security checklist for production

1. Change the admin password (update `admins` table)
2. Move `includes/config.php` credentials to environment variables
3. Enable HTTPS (Let's Encrypt)
4. Set `DB_PORT` and credentials to production values
5. Remove the sample products if not needed
6. Set `chmod 775` only on `uploads/products`, not the whole tree
