<?php
require_once __DIR__ . '/includes/functions.php';
$page = ['title' => 'About — Damentracht', 'description' => 'The story behind Damentracht — curated, artisan-made Indian lifestyle goods.'];
include __DIR__ . '/includes/header.php';
?>
<div class="container">
  <div class="page-head"><span class="eyebrow">Our Story</span><h1>Crafted in India, made for everyone</h1></div>
</div>
<section class="section" style="padding-top:0">
  <div class="container about-grid">
    <div class="about-text reveal">
      <p>Damentracht was born from a simple idea: that the incredible craft traditions of India deserve a modern home online. We work directly with artisans, weavers and small studios across the country to bring you objects that are honest, beautiful and made to last.</p>
      <p>From handloom textiles in West Bengal to brass work in Moradabad and block printing in Bagru, every product has a story — and a maker who is paid fairly for their skill.</p>
      <p>We believe in slow, considered shopping. No fast fashion, no throwaway goods. Just pieces you'll keep for years.</p>
    </div>
    <div class="about-visual reveal"></div>
  </div>
</section>

<section class="section" style="padding-top:0">
  <div class="container">
    <div class="section-head"><span class="eyebrow">What we stand for</span><h2>Our values</h2></div>
    <div class="values-grid">
      <div class="value-card reveal">
        <h3>Fair trade</h3>
        <p>We pay our artisans directly and fairly. No middlemen, no exploitation — just honest work for honest pay.</p>
      </div>
      <div class="value-card reveal">
        <h3>Natural materials</h3>
        <p>We favour cotton, linen, brass, wood and natural dyes. Materials that age well and tread lightly on the planet.</p>
      </div>
      <div class="value-card reveal">
        <h3>Made to last</h3>
        <p>Every piece is built for a lifetime of use, not a season. We design out waste and design in durability.</p>
      </div>
    </div>
  </div>
</section>
<?php include __DIR__ . '/includes/footer.php'; ?>
