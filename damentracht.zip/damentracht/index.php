<?php
require_once __DIR__ . '/includes/functions.php';
$featured = get_featured_products(8);
$cats = get_categories();
$page = [
    'title' => setting('meta_title', DEFAULT_META_TITLE),
    'description' => setting('meta_description', DEFAULT_META_DESC),
];
include __DIR__ . '/includes/header.php';
?>
<section class="hero">
  <div class="hero-inner">
    <div class="hero-eyebrow">Handcrafted in India</div>
    <h1>Curated goods for the <em>modern Indian</em> home &amp; wardrobe</h1>
    <p>Discover artisan-made apparel, home decor, accessories and wellness products sourced from craftspeople across India.</p>
    <div class="hero-cta">
      <a class="btn btn-primary" href="#featured">Shop Featured</a>
      <a class="btn btn-outline" href="<?= e(BASE_URL) ?>/about.php">Our Story</a>
    </div>
  </div>
</section>

<section class="section" id="featured">
  <div class="container">
    <div class="section-head reveal">
      <span class="eyebrow">Featured</span>
      <h2>Handpicked for you</h2>
      <p>A selection of our most-loved pieces, crafted by artisans and made to last.</p>
    </div>
    <div class="product-grid">
      <?php foreach ($featured as $p): ?>
        <?php include __DIR__ . '/includes/product_card.php'; ?>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php if ($cats): ?>
<section class="section" style="padding-top:0">
  <div class="container">
    <div class="section-head reveal">
      <span class="eyebrow">Collections</span>
      <h2>Shop by category</h2>
    </div>
    <div class="product-grid">
      <?php foreach ($cats as $c): ?>
      <a class="product-card reveal" href="<?= e(BASE_URL) ?>/category.php?slug=<?= e($c['slug']) ?>">
        <div class="product-thumb" style="display:grid;place-items:center;background:linear-gradient(135deg,var(--accent-d),var(--bg-soft))">
          <span style="font-family:var(--ff-head);font-size:1.4rem;color:rgba(255,255,255,.25)"><?= e($c['name']) ?></span>
        </div>
        <div class="product-info">
          <span class="product-cat">Collection</span>
          <span class="product-name"><?= e($c['name']) ?></span>
          <span class="product-price"><span class="price-now">Explore →</span></span>
        </div>
      </a>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<section class="section" style="background:var(--bg-soft);border-top:1px solid var(--line);border-bottom:1px solid var(--line)">
  <div class="container about-grid">
    <div class="about-text reveal">
      <span class="eyebrow">Our Promise</span>
      <h2 style="font-size:2rem;margin-bottom:18px">Made by hand, made to last</h2>
      <p>Every product on Damentracht is sourced directly from artisans and small studios across the country. We believe in fair wages, natural materials, and objects that age beautifully.</p>
      <p>No mass production. No middlemen. Just honest craft, delivered to your door.</p>
      <a class="btn btn-primary" href="<?= e(BASE_URL) ?>/about.php" style="margin-top:12px">Read our story</a>
    </div>
    <div class="about-visual reveal"></div>
  </div>
</section>

<?php include __DIR__ . '/includes/footer.php'; ?>
