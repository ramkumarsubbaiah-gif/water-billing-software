// Damentracht — storefront interactions
(function () {
  'use strict';

  // Mobile nav toggle
  var toggle = document.querySelector('.nav-toggle');
  var nav = document.getElementById('primary-nav');
  if (toggle && nav) {
    toggle.addEventListener('click', function () {
      var open = nav.classList.toggle('open');
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  }

  // Sticky header shadow on scroll
  var header = document.getElementById('header');
  if (header) {
    var onScroll = function () {
      header.classList.toggle('scrolled', window.scrollY > 20);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  // Toast helper
  window.toast = function (msg) {
    var t = document.querySelector('.toast');
    if (!t) {
      t = document.createElement('div');
      t.className = 'toast';
      document.body.appendChild(t);
    }
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(t._timer);
    t._timer = setTimeout(function () { t.classList.remove('show'); }, 2600);
  };

  // Reveal on scroll
  var reveals = document.querySelectorAll('.reveal');
  if (reveals.length && 'IntersectionObserver' in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) {
          en.target.classList.add('in');
          io.unobserve(en.target);
        }
      });
    }, { threshold: 0.12 });
    reveals.forEach(function (el) { io.observe(el); });
  } else {
    reveals.forEach(function (el) { el.classList.add('in'); });
  }

  // Add to cart (storefront)
  document.querySelectorAll('[data-add-to-cart]').forEach(function (btn) {
    btn.addEventListener('click', function (e) {
      e.preventDefault();
      var id = btn.getAttribute('data-add-to-cart');
      var qty = parseInt(btn.getAttribute('data-qty') || '1', 10);
      fetch(BASE_URL + '/cart.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'action=add&id=' + encodeURIComponent(id) + '&qty=' + encodeURIComponent(qty)
      }).then(function (r) { return r.json(); }).then(function (data) {
        if (data.ok) {
          var c = document.querySelector('.cart-count');
          if (c) { c.textContent = data.count; c.classList.add('has'); }
          window.toast(data.message || 'Added to cart');
        } else {
          window.toast(data.message || 'Could not add to cart');
        }
      }).catch(function () { window.toast('Network error'); });
    });
  });

  // Qty controls on product page
  document.querySelectorAll('.qty-control').forEach(function (qc) {
    var input = qc.querySelector('input');
    var minus = qc.querySelector('[data-qty-minus]');
    var plus = qc.querySelector('[data-qty-plus]');
    if (!input) return;
    var min = parseInt(input.min || '1', 10);
    if (minus) minus.addEventListener('click', function () {
      var v = parseInt(input.value || '1', 10);
      if (v > min) input.value = v - 1;
    });
    if (plus) plus.addEventListener('click', function () {
      var v = parseInt(input.value || '1', 10);
      input.value = v + 1;
    });
  });

  // Cart page qty update + remove
  var cartForm = document.querySelector('[data-cart-form]');
  if (cartForm) {
    cartForm.querySelectorAll('[data-cart-qty]').forEach(function (sel) {
      sel.addEventListener('change', function () {
        var id = sel.getAttribute('data-cart-qty');
        var qty = sel.value;
        fetch(BASE_URL + '/cart.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: 'action=update&id=' + encodeURIComponent(id) + '&qty=' + encodeURIComponent(qty)
        }).then(function (r) { return r.json(); }).then(function () {
          window.location.reload();
        });
      });
    });
    cartForm.querySelectorAll('[data-cart-remove]').forEach(function (btn) {
      btn.addEventListener('click', function (e) {
        e.preventDefault();
        var id = btn.getAttribute('data-cart-remove');
        fetch(BASE_URL + '/cart.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: 'action=remove&id=' + encodeURIComponent(id)
        }).then(function (r) { return r.json(); }).then(function () {
          window.location.reload();
        });
      });
    });
  }

  // Admin: image preview on file select
  document.querySelectorAll('[data-image-input]').forEach(function (input) {
    input.addEventListener('change', function () {
      var prev = document.querySelector(input.getAttribute('data-image-preview') || '.image-preview img');
      if (!prev) return;
      var file = input.files[0];
      if (file) {
        var reader = new FileReader();
        reader.onload = function (e) { prev.src = e.target.result; prev.style.display = 'block'; };
        reader.readAsDataURL(file);
      }
    });
  });

  // Admin: toggle switches
  document.querySelectorAll('.toggle').forEach(function (t) {
    t.addEventListener('click', function () {
      var hidden = t.parentElement.querySelector('input[type="hidden"]');
      t.classList.toggle('on');
      if (hidden) hidden.value = t.classList.contains('on') ? '1' : '0';
    });
  });

  // Admin: confirm delete
  document.querySelectorAll('[data-confirm]').forEach(function (el) {
    el.addEventListener('click', function (e) {
      if (!confirm(el.getAttribute('data-confirm'))) e.preventDefault();
    });
  });
})();
