-- ============================================================
--  Damentracht — E-Commerce Database Schema (MySQL / MAMP)
--  Import this file via phpMyAdmin (http://localhost/phpMyAdmin)
--  or the MAMP MySQL command line.
-- ============================================================

CREATE DATABASE IF NOT EXISTS damentracht
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_unicode_ci;

USE damentracht;

-- ----------------------------------------------------------
--  Admin users
-- ----------------------------------------------------------
CREATE TABLE IF NOT EXISTS admins (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name          VARCHAR(120) NOT NULL,
  email         VARCHAR(160) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_admin_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------
--  Categories
-- ----------------------------------------------------------
CREATE TABLE IF NOT EXISTS categories (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name        VARCHAR(120) NOT NULL,
  slug        VARCHAR(160) NOT NULL,
  description TEXT NULL,
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_cat_slug (slug)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------
--  Products
-- ----------------------------------------------------------
CREATE TABLE IF NOT EXISTS products (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  category_id   INT UNSIGNED NULL,
  name          VARCHAR(200) NOT NULL,
  slug          VARCHAR(220) NOT NULL,
  sku           VARCHAR(80)  NULL,
  short_desc    VARCHAR(300) NULL,
  description   TEXT NULL,
  price         DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  sale_price    DECIMAL(10,2) NULL,
  stock         INT NOT NULL DEFAULT 0,
  image         VARCHAR(255) NULL,
  gallery       TEXT NULL,
  is_featured   TINYINT(1) NOT NULL DEFAULT 0,
  is_active     TINYINT(1) NOT NULL DEFAULT 1,
  meta_title    VARCHAR(200) NULL,
  meta_description VARCHAR(320) NULL,
  meta_keywords VARCHAR(255) NULL,
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_prod_slug (slug),
  KEY idx_prod_category (category_id),
  KEY idx_prod_featured (is_featured),
  CONSTRAINT fk_prod_cat FOREIGN KEY (category_id)
    REFERENCES categories(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------
--  Orders
-- ----------------------------------------------------------
CREATE TABLE IF NOT EXISTS orders (
  id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
  customer_name   VARCHAR(160) NOT NULL,
  customer_email  VARCHAR(160) NOT NULL,
  customer_phone  VARCHAR(40)  NOT NULL,
  shipping_address TEXT NOT NULL,
  city            VARCHAR(120) NOT NULL,
  state           VARCHAR(120) NOT NULL,
  pincode         VARCHAR(12)  NOT NULL,
  payment_method  VARCHAR(40)  NOT NULL DEFAULT 'COD',
  total_amount    DECIMAL(10,2) NOT NULL,
  status          VARCHAR(40)  NOT NULL DEFAULT 'pending',
  notes           TEXT NULL,
  created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_order_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------
--  Order items
-- ----------------------------------------------------------
CREATE TABLE IF NOT EXISTS order_items (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  order_id    INT UNSIGNED NOT NULL,
  product_id  INT UNSIGNED NULL,
  product_name VARCHAR(200) NOT NULL,
  price       DECIMAL(10,2) NOT NULL,
  quantity    INT NOT NULL DEFAULT 1,
  PRIMARY KEY (id),
  KEY idx_oi_order (order_id),
  CONSTRAINT fk_oi_order FOREIGN KEY (order_id)
    REFERENCES orders(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------
--  Site settings (key/value)
-- ----------------------------------------------------------
CREATE TABLE IF NOT EXISTS settings (
  `key`       VARCHAR(80) NOT NULL,
  `value`     TEXT NULL,
  updated_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
--  Seed data
-- ============================================================

-- Default admin:  email admin@damentracht.in  / password admin123
INSERT INTO admins (name, email, password_hash) VALUES
  ('Administrator', 'admin@damentracht.in', '$2y$12$7Lm9UAuVLp65.RIhp7bnN.JhMaDHG2uySS.sG/tskhJn7kXb4kpoq');

-- Settings
INSERT INTO settings (`key`, `value`) VALUES
  ('site_name',        'Damentracht'),
  ('site_tagline',     'Curated Indian Lifestyle Goods'),
  ('site_email',       'hello@damentracht.in'),
  ('site_phone',       '+91 98765 43210'),
  ('site_address',     '123 Commercial Street, Bengaluru, Karnataka 560001, India'),
  ('currency_symbol',  '₹'),
  ('instagram_url',    'https://instagram.com/'),
  ('facebook_url',     'https://facebook.com/'),
  ('meta_title',       'Damentracht — Curated Indian Lifestyle Goods'),
  ('meta_description', 'Shop curated Indian lifestyle products — apparel, home decor, accessories and more. Free shipping across India.'),
  ('free_shipping_msg','Free shipping on orders over ₹999');

-- Categories
INSERT INTO categories (name, slug, description) VALUES
  ('Apparel',    'apparel',    'Clothing and garments crafted in India'),
  ('Home Decor', 'home-decor', 'Handcrafted decor for your living space'),
  ('Accessories','accessories','Bags, jewellery and everyday carry'),
  ('Wellness',   'wellness',   'Natural wellness and self-care goods');

-- Sample products (images are referenced from /assets/images/products/)
INSERT INTO products (category_id, name, slug, sku, short_desc, description, price, sale_price, stock, image, is_featured, is_active, meta_title, meta_description) VALUES
  (1, 'Handloom Cotton Kurta', 'handloom-cotton-kurta', 'AP-1001', 'Breathable handwoven cotton kurta',
   'A breathable handwoven cotton kurta made by artisan weavers in West Bengal. Natural dyes, straight cut, side slits for comfort.',
   1499.00, 1199.00, 40, 'sample-1.jpg', 1, 1,
   'Handloom Cotton Kurta — Damentracht', 'Handwoven cotton kurta in natural dyes by West Bengal artisans.'),
  (2, 'Brass Diya Set of 5', 'brass-diya-set-of-5', 'HD-2001', 'Traditional brass diyas for festivals',
   'A set of five polished brass diyas, handcrafted in Moradabad. Perfect for Diwali, pooja and everyday ambience.',
   899.00, NULL, 60, 'sample-2.jpg', 1, 1,
   'Brass Diya Set of 5 — Damentracht', 'Handcrafted brass diyas from Moradabad for festivals and decor.'),
  (3, 'Leather Journal', 'leather-journal', 'AC-3001', 'Full-grain leather bound journal',
   'A full-grain leather journal with 200 pages of acid-free paper. Hand-stitched in Rajasthan. Ages beautifully with use.',
   1299.00, 999.00, 25, 'sample-3.jpg', 1, 1,
   'Leather Journal — Damentracht', 'Full-grain leather journal hand-stitched in Rajasthan.'),
  (4, 'Ayurvedic Face Oil', 'ayurvedic-face-oil', 'WL-4001', 'Cold-pressed ayurvedic face oil',
   'A cold-pressed ayurvedic face oil with kumkumadi tailam blend. Suitable for all skin types. 30ml glass bottle.',
   749.00, NULL, 80, 'sample-4.jpg', 0, 1,
   'Ayurvedic Face Oil — Damentracht', 'Cold-pressed kumkumadi face oil for daily skincare.'),
  (1, 'Linen Shirt', 'linen-shirt', 'AP-1002', 'Lightweight breathable linen shirt',
   'A lightweight 100% linen shirt, tailored for the Indian summer. Mother-of-pearl buttons, relaxed fit.',
   1899.00, 1599.00, 30, 'sample-5.jpg', 1, 1,
   'Linen Shirt — Damentracht', 'Breathable 100% linen shirt tailored for Indian summers.'),
  (2, 'Block-print Cushion Cover', 'block-print-cushion-cover', 'HD-2002', 'Hand block-printed cotton cushion cover',
   'Hand block-printed cotton cushion cover from Bagru, Rajasthan. 18x18 inches, hidden zipper closure.',
   599.00, 449.00, 100, 'sample-6.jpg', 0, 1,
   'Block-print Cushion Cover — Damentracht', 'Bagru hand block-printed cotton cushion cover.');
