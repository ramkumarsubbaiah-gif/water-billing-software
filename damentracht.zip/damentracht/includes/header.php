<?php
// Shared header for the storefront. Expects $page array with SEO meta.
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/functions.php';
$meta = seo_meta($page ?? []);
$siteName = setting('site_name', 'Damentracht');
$tagline  = setting('site_tagline', 'Curated Indian Lifestyle Goods');
$freeShip = setting('free_shipping_msg', '');
$cartCount = function_exists('cart_count') ? cart_count() : 0;
$cats = get_categories();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($meta['title']) ?></title>
<meta name="description" content="<?= e($meta['description']) ?>">
<?php if (!empty($meta['keywords'])): ?>
<meta name="keywords" content="<?= e($meta['keywords']) ?>">
<?php endif; ?>
<meta name="robots" content="index, follow">
<link rel="canonical" href="<?= e((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http') . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . ($_SERVER['REQUEST_URI'] ?? '')) ?>">

<!-- Open Graph -->
<meta property="og:type" content="website">
<meta property="og:title" content="<?= e($meta['og_title']) ?>">
<meta property="og:description" content="<?= e($meta['og_desc']) ?>">
<meta property="og:image" content="<?= e($meta['og_image']) ?>">
<meta name="twitter:card" content="summary_large_image">

<!-- Fonts -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,500;9..144,600;9..144,700&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<link rel="stylesheet" href="<?= asset_url('css/style.css') ?>">
</head>
<body>
<a class="skip-link" href="#main">Skip to content</a>

<div class="announcement" role="banner">
  <div class="container"><?= e($freeShip ?: 'Handcrafted in India · Free shipping over ₹999') ?></div>
</div>

<header class="site-header" id="header">
  <div class="container header-inner">
    <button class="nav-toggle" aria-label="Open menu" aria-expanded="false" aria-controls="primary-nav">
      <span></span><span></span><span></span>
    </button>
    <a class="brand" href="<?= e(BASE_URL) ?>/index.php">
      <span class="brand-name"><?= e($siteName) ?></span>
      <span class="brand-tag"><?= e($tagline) ?></span>
    </a>
    <nav class="primary-nav" id="primary-nav" aria-label="Primary">
      <a href="<?= e(BASE_URL) ?>/index.php">Home</a>
      <?php foreach ($cats as $c): ?>
        <a href="<?= e(BASE_URL) ?>/category.php?slug=<?= e($c['slug']) ?>"><?= e($c['name']) ?></a>
      <?php endforeach; ?>
      <a href="<?= e(BASE_URL) ?>/about.php">About</a>
    </nav>
    <div class="header-actions">
      <a href="<?= e(BASE_URL) ?>/search.php" class="icon-btn" aria-label="Search">
        <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>
      </a>
      <a href="<?= e(BASE_URL) ?>/cart.php" class="icon-btn cart-btn" aria-label="Cart">
        <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M6 6h15l-1.5 9h-12z"/><circle cx="9" cy="20" r="1.5"/><circle cx="18" cy="20" r="1.5"/><path d="M6 6 5 3H2"/></svg>
        <span class="cart-count <?= $cartCount ? 'has' : '' ?>"><?= $cartCount ?></span>
      </a>
    </div>
  </div>
</header>

<main id="main">
