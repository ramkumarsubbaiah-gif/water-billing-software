<?php
// Database configuration for MAMP (local development)
// Default MAMP credentials: user "root", password "root" (Mac) or "" (Windows).
// Adjust DB_PASSWORD if your MAMP MySQL password differs.

define('DB_HOST', '127.0.0.1');
define('DB_PORT', '8889'); // MAMP default MySQL port (8889). Change to 3306 if you use default MySQL.
define('DB_NAME', 'damentracht');
define('DB_USER', 'root');
define('DB_PASS', 'root'); // Use '' on Windows MAMP/XAMPP, 'root' on Mac MAMP
define('DB_CHARSET', 'utf8mb4');

// Base URL — set to the folder name you place the project in under htdocs.
// e.g. http://localhost/damentracht  ->  BASE_URL = '/damentracht'
define('BASE_URL', '/damentracht');

// Upload directories
define('UPLOAD_DIR', __DIR__ . '/../uploads/products');
define('UPLOAD_URL', BASE_URL . '/uploads/products');

// Site defaults
define('DEFAULT_META_TITLE', 'Damentracht — Curated Indian Lifestyle Goods');
define('DEFAULT_META_DESC', 'Shop curated Indian lifestyle products — apparel, home decor, accessories and more. Free shipping across India.');
