<?php
// Reusable product card. Expects $p (product row).
$price = $p['sale_price'] ?? $p['price'];
$onSale = !empty($p['sale_price']) && (float)$p['sale_price'] < (float)$p['price'];
$catSlug = $p['category_slug'] ?? '';
$catName = $p['category_name'] ?? '';
?>
<article class="product-card reveal">
  <a href="<?= e(BASE_URL) ?>/product.php?slug=<?= e($p['slug']) ?>">
    <div class="product-thumb">
      <?php if ($onSale): ?><span class="product-badge">Sale</span><?php endif; ?>
      <img src="<?= e(product_image_url($p['image'] ?? null)) ?>" alt="<?= e($p['name']) ?>" loading="lazy" onerror="this.onerror=null;this.src='<?= e(asset_url('images/placeholder.svg')) ?>';">
    </div>
  </a>
  <div class="product-info">
    <?php if ($catName): ?><span class="product-cat"><?= e($catName) ?></span><?php endif; ?>
    <a href="<?= e(BASE_URL) ?>/product.php?slug=<?= e($p['slug']) ?>"><span class="product-name"><?= e($p['name']) ?></span></a>
    <div class="product-price">
      <span class="price-now"><?= e(money($price)) ?></span>
      <?php if ($onSale): ?><span class="price-was"><?= e(money($p['price'])) ?></span><?php endif; ?>
    </div>
    <button class="btn btn-outline btn-sm btn-block" style="margin-top:10px" data-add-to-cart="<?= e($p['id']) ?>">Add to cart</button>
  </div>
</article>
