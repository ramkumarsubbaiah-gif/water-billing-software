<?php
// Shared helper functions for storefront + admin.

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db.php';

// ----------------------------------------------------------
//  Output / escaping
// ----------------------------------------------------------
function e(?string $v): string {
    return htmlspecialchars($v ?? '', ENT_QUOTES, 'UTF-8');
}

function redirect(string $path): void {
    header('Location: ' . $path);
    exit;
}

function asset_url(string $path): string {
    return BASE_URL . '/assets/' . ltrim($path, '/');
}

function product_image_url(?string $image): string {
    if (!$image) return asset_url('images/placeholder.svg');
    $diskPath = UPLOAD_DIR . '/' . $image;
    if (!is_file($diskPath)) return asset_url('images/placeholder.svg');
    return UPLOAD_URL . '/' . rawurlencode($image);
}

// ----------------------------------------------------------
//  Formatting
// ----------------------------------------------------------
function money($amount): string {
    $cur = setting('currency_symbol', '₹');
    return $cur . number_format((float)$amount, 2, '.', ',');
}

function slugify(string $text): string {
    $text = preg_replace('~[^\pL\d]+~u', '-', $text);
    $text = trim($text, '-');
    $text = strtolower($text);
    $text = preg_replace('~[^-\w]+~', '', $text);
    return $text ?: 'item-' . time();
}

// ----------------------------------------------------------
//  Settings (cached)
// ----------------------------------------------------------
function setting(string $key, $default = null) {
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        try {
            $stmt = db()->query('SELECT `key`, `value` FROM settings');
            foreach ($stmt->fetchAll() as $row) {
                $cache[$row['key']] = $row['value'];
            }
        } catch (Throwable $e) {
            // settings table may not exist yet; fall back to defaults
        }
    }
    return $cache[$key] ?? $default;
}

function all_settings(): array {
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        try {
            $stmt = db()->query('SELECT `key`, `value` FROM settings');
            foreach ($stmt->fetchAll() as $row) $cache[$row['key']] = $row['value'];
        } catch (Throwable $e) {}
    }
    return $cache;
}

// ----------------------------------------------------------
//  Categories
// ----------------------------------------------------------
function get_categories(): array {
    return db()->query('SELECT * FROM categories ORDER BY name ASC')->fetchAll();
}

function get_category_by_slug(string $slug): ?array {
    $stmt = db()->prepare('SELECT * FROM categories WHERE slug = ?');
    $stmt->execute([$slug]);
    $row = $stmt->fetch();
    return $row ?: null;
}

// ----------------------------------------------------------
//  Products
// ----------------------------------------------------------
function get_featured_products(int $limit = 8): array {
    $stmt = db()->prepare(
        'SELECT p.*, c.slug AS category_slug, c.name AS category_name
         FROM products p LEFT JOIN categories c ON c.id = p.category_id
         WHERE p.is_active = 1 AND p.is_featured = 1
         ORDER BY p.created_at DESC LIMIT ' . (int)$limit
    );
    $stmt->execute();
    return $stmt->fetchAll();
}

function get_products(array $opts = []): array {
    $limit = $opts['limit'] ?? 12;
    $offset = $opts['offset'] ?? 0;
    $where = ['p.is_active = 1'];
    $params = [];
    if (!empty($opts['category_id'])) {
        $where[] = 'p.category_id = ?';
        $params[] = (int)$opts['category_id'];
    }
    if (!empty($opts['search'])) {
        $where[] = '(p.name LIKE ? OR p.short_desc LIKE ? OR p.description LIKE ?)';
        $like = '%' . $opts['search'] . '%';
        array_push($params, $like, $like, $like);
    }
    $sql = 'SELECT p.*, c.slug AS category_slug, c.name AS category_name
            FROM products p LEFT JOIN categories c ON c.id = p.category_id
            WHERE ' . implode(' AND ', $where) . '
            ORDER BY p.is_featured DESC, p.created_at DESC
            LIMIT ' . (int)$limit . ' OFFSET ' . (int)$offset;
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

function get_product_by_slug(string $slug): ?array {
    $stmt = db()->prepare(
        'SELECT p.*, c.slug AS category_slug, c.name AS category_name
         FROM products p LEFT JOIN categories c ON c.id = p.category_id
         WHERE p.slug = ? AND p.is_active = 1 LIMIT 1'
    );
    $stmt->execute([$slug]);
    $row = $stmt->fetch();
    return $row ?: null;
}

function get_related_products(int $categoryId, int $excludeId, int $limit = 4): array {
    $stmt = db()->prepare(
        'SELECT * FROM products
         WHERE category_id = ? AND id <> ? AND is_active = 1
         ORDER BY RAND() LIMIT ' . (int)$limit
    );
    $stmt->execute([$categoryId, $excludeId]);
    return $stmt->fetchAll();
}

// ----------------------------------------------------------
//  Cart (session-based)
// ----------------------------------------------------------
function get_cart(): array {
    if (!isset($_SESSION['cart'])) $_SESSION['cart'] = [];
    return $_SESSION['cart'];
}

function cart_count(): int {
    $c = get_cart();
    $n = 0;
    foreach ($c as $qty) $n += (int)$qty;
    return $n;
}

function cart_total(): float {
    $cart = get_cart();
    if (!$cart) return 0.0;
    $ids = array_keys($cart);
    $in = implode(',', array_fill(0, count($ids), '?'));
    $stmt = db()->prepare("SELECT id, price, sale_price FROM products WHERE id IN ($in)");
    $stmt->execute($ids);
    $total = 0.0;
    foreach ($stmt->fetchAll() as $p) {
        $price = $p['sale_price'] ?? $p['price'];
        $total += (float)$price * (int)$cart[$p['id']];
    }
    return $total;
}

function cart_items(): array {
    $cart = get_cart();
    if (!$cart) return [];
    $ids = array_keys($cart);
    $in = implode(',', array_fill(0, count($ids), '?'));
    $stmt = db()->prepare(
        "SELECT p.*, c.slug AS category_slug FROM products p
         LEFT JOIN categories c ON c.id = p.category_id
         WHERE p.id IN ($in)"
    );
    $stmt->execute($ids);
    $items = [];
    foreach ($stmt->fetchAll() as $p) {
        $price = $p['sale_price'] ?? $p['price'];
        $qty = (int)$cart[$p['id']];
        $items[] = [
            'id'       => $p['id'],
            'name'     => $p['name'],
            'slug'     => $p['slug'],
            'image'    => $p['image'],
            'price'    => (float)$price,
            'base_price' => (float)$p['price'],
            'qty'      => $qty,
            'subtotal' => (float)$price * $qty,
        ];
    }
    return $items;
}

// ----------------------------------------------------------
//  Flash messages
// ----------------------------------------------------------
function flash(string $key, ?string $msg = null): ?string {
    if ($msg !== null) {
        $_SESSION['flash'][$key] = $msg;
        return null;
    }
    $v = $_SESSION['flash'][$key] ?? null;
    unset($_SESSION['flash'][$key]);
    return $v;
}

// ----------------------------------------------------------
//  SEO meta helper
// ----------------------------------------------------------
function seo_meta(array $page = []): array {
    $title = $page['title'] ?? setting('meta_title', DEFAULT_META_TITLE);
    $desc  = $page['description'] ?? setting('meta_description', DEFAULT_META_DESC);
    $keywords = $page['keywords'] ?? '';
    return [
        'title'       => $title,
        'description' => $desc,
        'keywords'    => $keywords,
        'og_title'    => $title,
        'og_desc'     => $desc,
        'og_image'    => $page['image'] ?? asset_url('images/og-default.svg'),
    ];
}
