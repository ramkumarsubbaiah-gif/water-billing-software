<?php
$siteName = setting('site_name', 'Damentracht');
$email = setting('site_email', 'hello@damentracht.in');
$phone = setting('site_phone', '');
$address = setting('site_address', '');
$insta = setting('instagram_url', '');
$fb = setting('facebook_url', '');
$cats = get_categories();
?>
</main>

<footer class="site-footer">
  <div class="container footer-grid">
    <div class="footer-col">
      <h3 class="brand-name"><?= e($siteName) ?></h3>
      <p class="footer-tag">Curated Indian lifestyle goods, crafted by artisans across the country.</p>
      <?php if ($insta || $fb): ?>
      <div class="socials">
        <?php if ($insta): ?><a href="<?= e($insta) ?>" target="_blank" rel="noopener" aria-label="Instagram">Instagram</a><?php endif; ?>
        <?php if ($fb): ?><a href="<?= e($fb) ?>" target="_blank" rel="noopener" aria-label="Facebook">Facebook</a><?php endif; ?>
      </div>
      <?php endif; ?>
    </div>
    <div class="footer-col">
      <h4>Shop</h4>
      <ul>
        <?php foreach ($cats as $c): ?>
          <li><a href="<?= e(BASE_URL) ?>/category.php?slug=<?= e($c['slug']) ?>"><?= e($c['name']) ?></a></li>
        <?php endforeach; ?>
      </ul>
    </div>
    <div class="footer-col">
      <h4>Company</h4>
      <ul>
        <li><a href="<?= e(BASE_URL) ?>/about.php">About Us</a></li>
        <li><a href="<?= e(BASE_URL) ?>/contact.php">Contact</a></li>
        <li><a href="<?= e(BASE_URL) ?>/admin/login.php">Admin</a></li>
      </ul>
    </div>
    <div class="footer-col">
      <h4>Get in touch</h4>
      <ul>
        <?php if ($email): ?><li><a href="mailto:<?= e($email) ?>"><?= e($email) ?></a></li><?php endif; ?>
        <?php if ($phone): ?><li><?= e($phone) ?></li><?php endif; ?>
        <?php if ($address): ?><li><?= e($address) ?></li><?php endif; ?>
      </ul>
    </div>
  </div>
  <div class="footer-bottom">
    <div class="container">
      <p>&copy; <?= date('Y') ?> <?= e($siteName) ?>. All rights reserved.</p>
      <p class="pay-note">Cash on Delivery · Secure Checkout · Made in India</p>
    </div>
  </div>
</footer>

<script>window.BASE_URL = <?= json_encode(BASE_URL) ?>;</script>
<script src="<?= asset_url('js/main.js') ?>"></script>
</body>
</html>
