<?php
require_once __DIR__ . '/includes/functions.php';
$slug = $_GET['slug'] ?? '';
$category = get_category_by_slug($slug);
if (!$category) {
    http_response_code(404);
    $page = ['title' => 'Category not found — Damentracht'];
    include __DIR__ . '/includes/header.php';
    echo '<div class="container"><div class="empty-state"><h3>Category not found</h3><a class="btn btn-primary" href="' . e(BASE_URL) . '/index.php" style="margin-top:18px">Back to home</a></div></div>';
    include __DIR__ . '/includes/footer.php';
    exit;
}
$products = get_products(['category_id' => $category['id'], 'limit' => 100]);
$page = [
    'title' => $category['name'] . ' — Damentracht',
    'description' => $category['description'] ?: ('Shop ' . $category['name'] . ' at Damentracht.'),
];
include __DIR__ . '/includes/header.php';
?>
<div class="container">
  <nav class="breadcrumb"><a href="<?= e(BASE_URL) ?>/index.php">Home</a><span>/</span> <?= e($category['name']) ?></nav>
</div>
<section class="section" style="padding-top:0">
  <div class="container">
    <div class="page-head" style="text-align:left;padding-top:0">
      <h1><?= e($category['name']) ?></h1>
      <?php if ($category['description']): ?><p><?= e($category['description']) ?></p><?php endif; ?>
    </div>
    <?php if ($products): ?>
    <div class="product-grid">
      <?php foreach ($products as $p): include __DIR__ . '/includes/product_card.php'; endforeach; ?>
    </div>
    <?php else: ?>
    <div class="empty-state"><h3>No products yet</h3><p>Check back soon — new arrivals are on the way.</p></div>
    <?php endif; ?>
  </div>
</section>
<?php include __DIR__ . '/includes/footer.php'; ?>
