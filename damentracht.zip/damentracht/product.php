<?php
require_once __DIR__ . '/includes/functions.php';
$slug = $_GET['slug'] ?? '';
$product = get_product_by_slug($slug);
if (!$product) {
    http_response_code(404);
    $page = ['title' => 'Product not found — Damentracht'];
    include __DIR__ . '/includes/header.php';
    echo '<div class="container"><div class="empty-state"><h3>Product not found</h3><p>The product you are looking for may have been removed.</p><a class="btn btn-primary" href="' . e(BASE_URL) . '/index.php" style="margin-top:18px">Back to home</a></div></div>';
    include __DIR__ . '/includes/footer.php';
    exit;
}
$related = get_related_products((int)$product['category_id'], (int)$product['id'], 4);
$price = $product['sale_price'] ?? $product['price'];
$onSale = !empty($product['sale_price']) && (float)$product['sale_price'] < (float)$product['price'];
$inStock = (int)$product['stock'] > 0;
$page = [
    'title' => $product['meta_title'] ?: ($product['name'] . ' — Damentracht'),
    'description' => $product['meta_description'] ?: ($product['short_desc'] ?: substr(strip_tags($product['description']), 0, 160)),
    'keywords' => $product['meta_keywords'] ?? '',
    'image' => product_image_url($product['image']),
];
include __DIR__ . '/includes/header.php';
?>
<div class="container">
  <nav class="breadcrumb" aria-label="Breadcrumb">
    <a href="<?= e(BASE_URL) ?>/index.php">Home</a>
    <?php if (!empty($product['category_slug'])): ?>
    <span>/</span><a href="<?= e(BASE_URL) ?>/category.php?slug=<?= e($product['category_slug']) ?>"><?= e($product['category_name']) ?></a>
    <?php endif; ?>
    <span>/</span> <?= e($product['name']) ?>
  </nav>
</div>

<section class="section" style="padding-top:0">
  <div class="container">
    <div class="product-detail">
      <div class="product-gallery reveal">
        <div class="main-img">
          <img src="<?= e(product_image_url($product['image'])) ?>" alt="<?= e($product['name']) ?>" onerror="this.onerror=null;this.src='<?= e(asset_url('images/placeholder.svg')) ?>';">
        </div>
      </div>
      <div class="product-info-block reveal">
        <?php if (!empty($product['category_name'])): ?><span class="product-cat"><?= e($product['category_name']) ?></span><?php endif; ?>
        <h1><?= e($product['name']) ?></h1>
        <?php if ($product['short_desc']): ?><p class="short-desc"><?= e($product['short_desc']) ?></p><?php endif; ?>

        <div class="price-row">
          <span class="price-now"><?= e(money($price)) ?></span>
          <?php if ($onSale): ?><span class="price-was"><?= e(money($product['price'])) ?></span><?php endif; ?>
          <?php if (!empty($product['sku'])): ?><span class="hint" style="margin-left:auto">SKU: <?= e($product['sku']) ?></span><?php endif; ?>
        </div>

        <span class="stock-pill <?= $inStock ? '' : 'out' ?>"><?= $inStock ? 'In stock' : 'Out of stock' ?></span>

        <?php if ($inStock): ?>
        <div class="qty-row">
          <label style="font-size:13px;color:var(--ink-soft)">Quantity</label>
          <div class="qty-control">
            <button type="button" data-qty-minus aria-label="Decrease">−</button>
            <input type="number" id="qty" value="1" min="1" max="<?= (int)$product['stock'] ?>" aria-label="Quantity">
            <button type="button" data-qty-plus aria-label="Increase">+</button>
          </div>
        </div>
        <button class="btn btn-primary btn-block" data-add-to-cart="<?= e($product['id']) ?>" data-qty="1" id="add-to-cart-btn">Add to cart</button>
        <a class="btn btn-outline btn-block" href="<?= e(BASE_URL) ?>/cart.php" style="margin-top:10px">View cart</a>
        <?php else: ?>
        <p class="error-text">This product is currently out of stock.</p>
        <?php endif; ?>

        <div class="product-desc">
          <h3>Description</h3>
          <p><?= nl2br(e($product['description'])) ?></p>
        </div>
      </div>
    </div>
  </div>
</section>

<?php if ($related): ?>
<section class="section" style="padding-top:0">
  <div class="container">
    <div class="section-head">
      <span class="eyebrow">You may also like</span>
      <h2>Related products</h2>
    </div>
    <div class="product-grid">
      <?php foreach ($related as $p): include __DIR__ . '/includes/product_card.php'; endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<script>
document.getElementById('add-to-cart-btn')?.addEventListener('click', function(){
  var q = document.getElementById('qty');
  if (q) this.setAttribute('data-qty', q.value);
});
</script>
<?php include __DIR__ . '/includes/footer.php'; ?>
