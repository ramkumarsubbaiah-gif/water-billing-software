<?php
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/auth.php';
if (is_admin_logged_in()) redirect(BASE_URL . '/admin/index.php');

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    if (!$email || !$password) {
        $error = 'Please enter your email and password.';
    } elseif (admin_login($email, $password)) {
        redirect(BASE_URL . '/admin/index.php');
    } else {
        $error = 'Invalid credentials. Please try again.';
    }
}
$siteName = setting('site_name', 'Damentracht');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title>Admin Login — <?= e($siteName) ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Fraunces:wght@500;600&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= e(BASE_URL) ?>/assets/css/style.css">
</head>
<body class="admin-body">
<div class="login-wrap">
  <div class="login-card">
    <span class="brand-name" style="font-family:var(--ff-head);font-size:24px;color:var(--primary)"><?= e($siteName) ?></span>
    <h1>Admin Login</h1>
    <p class="sub">Sign in to manage your store</p>
    <?php if ($error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>
    <form method="post" class="form-grid">
      <div class="field">
        <label for="email">Email</label>
        <input type="email" id="email" name="email" required value="<?= e($_POST['email'] ?? '') ?>">
      </div>
      <div class="field">
        <label for="password">Password</label>
        <input type="password" id="password" name="password" required>
      </div>
      <button class="btn btn-primary btn-block" type="submit">Sign in</button>
    </form>
    <p class="hint" style="text-align:center;margin-top:18px">Default: admin@damentracht.in / admin123</p>
  </div>
</div>
</body>
</html>
