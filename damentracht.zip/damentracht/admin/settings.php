<?php
require_once __DIR__ . '/header.php';
$activeNav = 'settings';
$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fields = ['site_name','site_tagline','site_email','site_phone','site_address','currency_symbol','instagram_url','facebook_url','meta_title','meta_description','free_shipping_msg'];
    try {
        $stmt = db()->prepare('INSERT INTO settings (`key`,`value`) VALUES (?,?) ON DUPLICATE KEY UPDATE `value`=VALUES(`value`)');
        foreach ($fields as $f) {
            $stmt->execute([$f, $_POST[$f] ?? '']);
        }
        $success = 'Settings saved.';
    } catch (Throwable $e) {
        $error = 'Could not save settings.';
    }
}

$s = all_settings();
?>
<?php if ($error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>
<?php if ($success): ?><div class="alert alert-success"><?= e($success) ?></div><?php endif; ?>

<form method="post" style="max-width:760px">
  <div class="admin-panel">
    <h2>Store information</h2>
    <div class="form-grid">
      <div class="field-row">
        <div class="field"><label for="site_name">Site name</label><input id="site_name" name="site_name" value="<?= e($s['site_name'] ?? '') ?>"></div>
        <div class="field"><label for="site_tagline">Tagline</label><input id="site_tagline" name="site_tagline" value="<?= e($s['site_tagline'] ?? '') ?>"></div>
      </div>
      <div class="field-row">
        <div class="field"><label for="site_email">Contact email</label><input type="email" id="site_email" name="site_email" value="<?= e($s['site_email'] ?? '') ?>"></div>
        <div class="field"><label for="site_phone">Phone</label><input id="site_phone" name="site_phone" value="<?= e($s['site_phone'] ?? '') ?>"></div>
      </div>
      <div class="field"><label for="site_address">Address</label><textarea id="site_address" name="site_address"><?= e($s['site_address'] ?? '') ?></textarea></div>
      <div class="field"><label for="currency_symbol">Currency symbol</label><input id="currency_symbol" name="currency_symbol" value="<?= e($s['currency_symbol'] ?? '₹') ?>"></div>
      <div class="field"><label for="free_shipping_msg">Announcement bar text</label><input id="free_shipping_msg" name="free_shipping_msg" value="<?= e($s['free_shipping_msg'] ?? '') ?>"></div>
    </div>
  </div>

  <div class="admin-panel">
    <h2>Social links</h2>
    <div class="form-grid">
      <div class="field"><label for="instagram_url">Instagram URL</label><input id="instagram_url" name="instagram_url" value="<?= e($s['instagram_url'] ?? '') ?>"></div>
      <div class="field"><label for="facebook_url">Facebook URL</label><input id="facebook_url" name="facebook_url" value="<?= e($s['facebook_url'] ?? '') ?>"></div>
    </div>
  </div>

  <div class="admin-panel">
    <h2>SEO defaults</h2>
    <div class="form-grid">
      <div class="field"><label for="meta_title">Default meta title</label><input id="meta_title" name="meta_title" maxlength="200" value="<?= e($s['meta_title'] ?? '') ?>"></div>
      <div class="field"><label for="meta_description">Default meta description</label><textarea id="meta_description" name="meta_description" maxlength="320"><?= e($s['meta_description'] ?? '') ?></textarea></div>
    </div>
  </div>

  <button class="btn btn-primary" type="submit">Save settings</button>
</form>
<?php include __DIR__ . '/footer.php'; ?>
