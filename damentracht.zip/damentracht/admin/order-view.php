<?php
require_once __DIR__ . '/header.php';
$id = (int)($_GET['id'] ?? 0);
$stmt = db()->prepare('SELECT * FROM orders WHERE id = ?');
$stmt->execute([$id]);
$order = $stmt->fetch();
if (!$order) redirect(BASE_URL . '/admin/orders.php');

$items = db()->prepare('SELECT oi.*, p.slug FROM order_items oi LEFT JOIN products p ON p.id = oi.product_id WHERE oi.order_id = ?');
$items->execute([$id]);
$items = $items->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $newStatus = $_POST['status'] ?? 'pending';
    $valid = ['pending','processing','completed','cancelled'];
    if (in_array($newStatus, $valid)) {
        db()->prepare('UPDATE orders SET status = ? WHERE id = ?')->execute([$newStatus, $id]);
        redirect(BASE_URL . '/admin/order-view.php?id=' . $id);
    }
}
?>
<a href="<?= e(BASE_URL) ?>/admin/orders.php" class="btn btn-ghost btn-sm" style="margin-bottom:16px">← Back to orders</a>

<div class="admin-panel">
  <h2>Order #<?= (int)$order['id'] ?></h2>
  <p style="color:var(--ink-mute);margin-bottom:20px">Placed on <?= e(date('d M Y, H:i', strtotime($order['created_at']))) ?></p>

  <form method="post" style="margin-bottom:24px">
    <div class="field" style="max-width:280px">
      <label for="status">Update status</label>
      <select id="status" name="status" onchange="this.form.submit()">
        <?php foreach (['pending','processing','completed','cancelled'] as $s): ?>
          <option value="<?= $s ?>" <?= $order['status']===$s ? 'selected' : '' ?>><?= e(ucfirst($s)) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
  </form>

  <h3 style="margin-bottom:14px">Customer details</h3>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px 32px;color:var(--ink-soft);margin-bottom:24px">
    <p><strong>Name:</strong> <?= e($order['customer_name']) ?></p>
    <p><strong>Phone:</strong> <?= e($order['customer_phone']) ?></p>
    <p><strong>Email:</strong> <?= e($order['customer_email']) ?></p>
    <p><strong>Payment:</strong> <?= e($order['payment_method']) ?></p>
    <p><strong>City:</strong> <?= e($order['city']) ?></p>
    <p><strong>State:</strong> <?= e($order['state']) ?></p>
    <p><strong>PIN:</strong> <?= e($order['pincode']) ?></p>
    <p><strong>Status:</strong> <?= e(ucfirst($order['status'])) ?></p>
    <p style="grid-column:1/-1"><strong>Address:</strong> <?= e($order['shipping_address']) ?></p>
    <?php if ($order['notes']): ?><p style="grid-column:1/-1"><strong>Notes:</strong> <?= e($order['notes']) ?></p><?php endif; ?>
  </div>

  <h3 style="margin-bottom:14px">Items</h3>
  <table class="admin-table">
    <thead><tr><th>Product</th><th>Price</th><th>Qty</th><th>Subtotal</th></tr></thead>
    <tbody>
      <?php foreach ($items as $it): ?>
      <tr>
        <td><?= e($it['product_name']) ?></td>
        <td><?= e(money($it['price'])) ?></td>
        <td><?= (int)$it['quantity'] ?></td>
        <td><?= e(money($it['price'] * $it['quantity'])) ?></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
  <p style="text-align:right;font-size:1.2rem;margin-top:16px"><strong>Total: <?= e(money($order['total_amount'])) ?></strong></p>
</div>
<?php include __DIR__ . '/footer.php'; ?>
