<?php
require_once __DIR__ . '/header.php';
$activeNav = 'dashboard';

// Stats
$productCount = (int) db()->query('SELECT COUNT(*) FROM products')->fetchColumn();
$activeProducts = (int) db()->query('SELECT COUNT(*) FROM products WHERE is_active = 1')->fetchColumn();
$orderCount = (int) db()->query('SELECT COUNT(*) FROM orders')->fetchColumn();
$pendingOrders = (int) db()->query("SELECT COUNT(*) FROM orders WHERE status = 'pending'")->fetchColumn();
$revenue = (float) db()->query("SELECT COALESCE(SUM(total_amount),0) FROM orders WHERE status <> 'cancelled'")->fetchColumn();
$lowStock = db()->query('SELECT name, stock, slug FROM products WHERE stock < 10 AND is_active = 1 ORDER BY stock ASC LIMIT 5')->fetchAll();
$recentOrders = db()->query('SELECT id, customer_name, total_amount, status, created_at FROM orders ORDER BY created_at DESC LIMIT 5')->fetchAll();
?>
<div class="admin-cards">
  <div class="stat-card"><div class="label">Products</div><div class="value"><?= $productCount ?></div><div class="sub"><?= $activeProducts ?> active</div></div>
  <div class="stat-card"><div class="label">Orders</div><div class="value"><?= $orderCount ?></div><div class="sub"><?= $pendingOrders ?> pending</div></div>
  <div class="stat-card"><div class="label">Revenue</div><div class="value"><?= e(money($revenue)) ?></div><div class="sub">excl. cancelled</div></div>
  <div class="stat-card"><div class="label">Low stock</div><div class="value"><?= count($lowStock) ?></div><div class="sub">items under 10</div></div>
</div>

<div class="admin-panel">
  <h2>Recent orders</h2>
  <?php if ($recentOrders): ?>
  <table class="admin-table">
    <thead><tr><th>#</th><th>Customer</th><th>Total</th><th>Status</th><th>Date</th><th></th></tr></thead>
    <tbody>
      <?php foreach ($recentOrders as $o): ?>
      <tr>
        <td>#<?= (int)$o['id'] ?></td>
        <td><?= e($o['customer_name']) ?></td>
        <td><?= e(money($o['total_amount'])) ?></td>
        <td><span class="badge <?= $o['status']==='pending'?'badge-amber':($o['status']==='completed'?'badge-green':'badge-red') ?>"><?= e(ucfirst($o['status'])) ?></span></td>
        <td><?= e(date('d M Y', strtotime($o['created_at']))) ?></td>
        <td><a href="<?= e(BASE_URL) ?>/admin/order-view.php?id=<?= (int)$o['id'] ?>" class="btn btn-ghost btn-sm">View</a></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
  <?php else: ?><p style="color:var(--ink-mute)">No orders yet.</p><?php endif; ?>
</div>

<div class="admin-panel">
  <h2>Low stock alerts</h2>
  <?php if ($lowStock): ?>
  <table class="admin-table">
    <thead><tr><th>Product</th><th>Stock</th><th></th></tr></thead>
    <tbody>
      <?php foreach ($lowStock as $p): ?>
      <tr>
        <td><?= e($p['name']) ?></td>
        <td><span class="badge <?= (int)$p['stock'] < 1 ? 'badge-red' : 'badge-amber' ?>"><?= (int)$p['stock'] ?> left</span></td>
        <td><a href="<?= e(BASE_URL) ?>/admin/product-edit.php?id=<?= e($p['slug']) ?>" class="btn btn-ghost btn-sm">Edit</a></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
  <?php else: ?><p style="color:var(--ink-mute)">All products well stocked.</p><?php endif; ?>
</div>
<?php include __DIR__ . '/footer.php'; ?>
