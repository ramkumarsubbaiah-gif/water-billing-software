<?php
require_once __DIR__ . '/header.php';
$activeNav = 'categories';
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $desc = trim($_POST['description'] ?? '');
    $editId = (int)($_POST['id'] ?? 0);
    if (!$name) {
        $error = 'Category name is required.';
    } else {
        $slug = slugify($name);
        try {
            if ($editId) {
                $stmt = db()->prepare('UPDATE categories SET name=?, slug=?, description=? WHERE id=?');
                $stmt->execute([$name, $slug, $desc, $editId]);
                $success = 'Category updated.';
            } else {
                $stmt = db()->prepare('INSERT INTO categories (name, slug, description) VALUES (?,?,?)');
                $stmt->execute([$name, $slug, $desc]);
                $success = 'Category added.';
            }
        } catch (Throwable $e) {
            $error = 'Could not save category (slug may already exist).';
        }
    }
}

if (isset($_GET['delete'])) {
    $delId = (int)$_GET['delete'];
    try {
        db()->prepare('DELETE FROM categories WHERE id = ?')->execute([$delId]);
        $success = 'Category deleted.';
    } catch (Throwable $e) {
        $error = 'Could not delete category.';
    }
}

$cats = db()->query('SELECT c.*, (SELECT COUNT(*) FROM products p WHERE p.category_id = c.id) AS product_count FROM categories c ORDER BY c.name ASC')->fetchAll();
?>
<?php if ($error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>
<?php if ($success): ?><div class="alert alert-success"><?= e($success) ?></div><?php endif; ?>

<div class="admin-panel">
  <h2>Add / edit category</h2>
  <form method="post" class="form-grid" style="max-width:520px">
    <input type="hidden" name="id" id="cat-id" value="">
    <div class="field"><label for="cat-name">Name</label><input id="cat-name" name="name" required></div>
    <div class="field"><label for="cat-desc">Description</label><textarea id="cat-desc" name="description"></textarea></div>
    <button class="btn btn-primary" type="submit">Save category</button>
  </form>
</div>

<div class="admin-panel" style="padding:0">
  <table class="admin-table">
    <thead><tr><th>Name</th><th>Slug</th><th>Products</th><th>Actions</th></tr></thead>
    <tbody>
      <?php foreach ($cats as $c): ?>
      <tr>
        <td><?= e($c['name']) ?></td>
        <td class="hint"><?= e($c['slug']) ?></td>
        <td><?= (int)$c['product_count'] ?></td>
        <td class="actions">
          <button class="btn btn-ghost btn-sm" onclick="document.getElementById('cat-id').value='<?= (int)$c['id'] ?>';document.getElementById('cat-name').value='<?= e($c['name']) ?>';document.getElementById('cat-desc').value='<?= e($c['description']) ?>';window.scrollTo(0,0);">Edit</button>
          <a href="<?= e(BASE_URL) ?>/admin/categories.php?delete=<?= (int)$c['id'] ?>" class="del btn btn-ghost btn-sm" data-confirm="Delete this category? Products in it will be uncategorised.">Delete</a>
        </td>
      </tr>
      <?php endforeach; ?>
      <?php if (!$cats): ?><tr><td colspan="4" style="text-align:center;color:var(--ink-mute);padding:30px">No categories yet.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>
<?php include __DIR__ . '/footer.php'; ?>
