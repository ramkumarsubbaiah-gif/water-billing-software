<?php
require_once __DIR__ . '/header.php';
$activeNav = 'product-new';

$id = isset($_GET['id']) ? $_GET['id'] : null;
$product = null;
if ($id) {
    $stmt = db()->prepare('SELECT * FROM products WHERE slug = ?');
    $stmt->execute([$id]);
    $product = $stmt->fetch();
    if (!$product) { redirect(BASE_URL . '/admin/products.php'); }
}
$cats = get_categories();
$error = '';
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name        = trim($_POST['name'] ?? '');
    $categoryId  = (int)($_POST['category_id'] ?? 0) ?: null;
    $sku         = trim($_POST['sku'] ?? '');
    $shortDesc   = trim($_POST['short_desc'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $price       = (float)($_POST['price'] ?? 0);
    $salePrice   = $_POST['sale_price'] !== '' ? (float)$_POST['sale_price'] : null;
    $stock       = (int)($_POST['stock'] ?? 0);
    $isActive    = (int)($_POST['is_active'] ?? 0);
    $isFeatured  = (int)($_POST['is_featured'] ?? 0);
    $metaTitle   = trim($_POST['meta_title'] ?? '');
    $metaDesc    = trim($_POST['meta_description'] ?? '');
    $metaKw      = trim($_POST['meta_keywords'] ?? '');
    $keepImage   = $_POST['keep_image'] ?? '';

    if (!$name) { $error = 'Product name is required.'; }
    elseif ($price <= 0) { $error = 'Price must be greater than zero.'; }
    else {
        $slug = slugify($name);
        // Ensure slug uniqueness
        $checkStmt = db()->prepare('SELECT id FROM products WHERE slug = ?' . ($product ? ' AND id <> ?' : ''));
        $params = [$slug];
        if ($product) $params[] = $product['id'];
        $checkStmt->execute($params);
        if ($checkStmt->fetch()) { $slug .= '-' . substr(uniqid(), -4); }

        // Handle image upload
        $imageName = $product['image'] ?? '';
        if (!empty($_FILES['image']['name']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $allowed = ['jpg','jpeg','png','webp','gif','svg'];
            $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
            if (!in_array($ext, $allowed)) {
                $error = 'Image must be JPG, PNG, WebP, GIF or SVG.';
            } else {
                if (!is_dir(UPLOAD_DIR)) @mkdir(UPLOAD_DIR, 0775, true);
                $imageName = $slug . '-' . time() . '.' . $ext;
                $dest = UPLOAD_DIR . '/' . $imageName;
                if (!move_uploaded_file($_FILES['image']['tmp_name'], $dest)) {
                    $error = 'Could not save uploaded image. Check folder permissions on uploads/products.';
                    $imageName = $product['image'] ?? '';
                }
            }
        } elseif (!$product && !$keepImage) {
            // no image for new product — that's ok, use placeholder
            $imageName = '';
        }

        if (!$error) {
            try {
                if ($product) {
                    $stmt = db()->prepare(
                        'UPDATE products SET category_id=?, name=?, slug=?, sku=?, short_desc=?, description=?, price=?, sale_price=?, stock=?, image=?, is_featured=?, is_active=?, meta_title=?, meta_description=?, meta_keywords=?, updated_at=NOW() WHERE id=?'
                    );
                    $stmt->execute([$categoryId,$name,$slug,$sku,$shortDesc,$description,$price,$salePrice,$stock,$imageName,$isFeatured,$isActive,$metaTitle,$metaDesc,$metaKw,$product['id']]);
                } else {
                    $stmt = db()->prepare(
                        'INSERT INTO products (category_id,name,slug,sku,short_desc,description,price,sale_price,stock,image,is_featured,is_active,meta_title,meta_description,meta_keywords,created_at,updated_at)
                         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,NOW(),NOW())'
                    );
                    $stmt->execute([$categoryId,$name,$slug,$sku,$shortDesc,$description,$price,$salePrice,$stock,$imageName,$isFeatured,$isActive,$metaTitle,$metaDesc,$metaKw]);
                }
                $success = true;
                // Reload product for form
                $stmt = db()->prepare('SELECT * FROM products WHERE slug = ?');
                $stmt->execute([$slug]);
                $product = $stmt->fetch();
                flash('saved', 'Product saved.');
                redirect(BASE_URL . '/admin/product-edit.php?id=' . urlencode($slug));
            } catch (Throwable $e) {
                $error = 'Could not save product: ' . $e->getMessage();
            }
        }
    }
}

$saved = flash('saved');
?>
<?php if ($error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>
<?php if ($saved): ?><div class="alert alert-success"><?= e($saved) ?></div><?php endif; ?>

<form method="post" enctype="multipart/form-data" style="max-width:760px">
  <div class="admin-panel">
    <h2><?= $product ? 'Edit product' : 'Add new product' ?></h2>
    <div class="form-grid">
      <div class="field">
        <label for="name">Product name *</label>
        <input id="name" name="name" required value="<?= e($product['name'] ?? $_POST['name'] ?? '') ?>">
      </div>
      <div class="field-row">
        <div class="field">
          <label for="category_id">Category</label>
          <select id="category_id" name="category_id">
            <option value="">— None —</option>
            <?php foreach ($cats as $c): ?>
              <option value="<?= (int)$c['id'] ?>" <?= ($product && $product['category_id']==$c['id']) || ($_POST['category_id']??'')==$c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="field">
          <label for="sku">SKU</label>
          <input id="sku" name="sku" value="<?= e($product['sku'] ?? $_POST['sku'] ?? '') ?>">
        </div>
      </div>
      <div class="field">
        <label for="short_desc">Short description</label>
        <input id="short_desc" name="short_desc" maxlength="300" value="<?= e($product['short_desc'] ?? $_POST['short_desc'] ?? '') ?>">
      </div>
      <div class="field">
        <label for="description">Full description</label>
        <textarea id="description" name="description"><?= e($product['description'] ?? $_POST['description'] ?? '') ?></textarea>
      </div>
    </div>
  </div>

  <div class="admin-panel">
    <h2>Pricing &amp; inventory</h2>
    <div class="form-grid">
      <div class="field-row">
        <div class="field">
          <label for="price">Price (₹) *</label>
          <input type="number" step="0.01" min="0" id="price" name="price" required value="<?= e($product['price'] ?? $_POST['price'] ?? '') ?>">
        </div>
        <div class="field">
          <label for="sale_price">Sale price (optional)</label>
          <input type="number" step="0.01" min="0" id="sale_price" name="sale_price" value="<?= e($product['sale_price'] ?? $_POST['sale_price'] ?? '') ?>">
        </div>
      </div>
      <div class="field">
        <label for="stock">Stock quantity</label>
        <input type="number" min="0" id="stock" name="stock" value="<?= e($product['stock'] ?? $_POST['stock'] ?? 0) ?>">
      </div>
    </div>
  </div>

  <div class="admin-panel">
    <h2>Product image</h2>
    <div class="field">
      <label for="image">Upload image (JPG, PNG, WebP, GIF, SVG)</label>
      <input type="file" id="image" name="image" accept="image/*" data-image-input data-image-preview="#img-prev">
      <?php if (!empty($product['image'])): ?>
        <input type="hidden" name="keep_image" value="<?= e($product['image']) ?>">
        <div class="image-preview"><img id="img-prev" src="<?= e(product_image_url($product['image'])) ?>" alt="Current image"></div>
      <?php else: ?>
        <div class="image-preview"><img id="img-prev" src="<?= e(asset_url('images/placeholder.svg')) ?>" alt="Preview" style="display:block"></div>
      <?php endif; ?>
      <span class="hint">Recommended: 800×1000px, under 2MB.</span>
    </div>
  </div>

  <div class="admin-panel">
    <h2>Visibility</h2>
    <div class="form-grid">
      <div class="toggle-row">
        <div class="toggle <?= ($product ? $product['is_active'] : true) ? 'on' : '' ?>"></div>
        <input type="hidden" name="is_active" value="<?= ($product ? $product['is_active'] : 1) ?>">
        <span>Active (visible on store)</span>
      </div>
      <div class="toggle-row">
        <div class="toggle <?= ($product['is_featured'] ?? 0) ? 'on' : '' ?>"></div>
        <input type="hidden" name="is_featured" value="<?= ($product['is_featured'] ?? 0) ?>">
        <span>Featured (shown on homepage)</span>
      </div>
    </div>
  </div>

  <div class="admin-panel">
    <h2>SEO (optional)</h2>
    <div class="form-grid">
      <div class="field">
        <label for="meta_title">Meta title</label>
        <input id="meta_title" name="meta_title" maxlength="200" value="<?= e($product['meta_title'] ?? $_POST['meta_title'] ?? '') ?>">
        <span class="hint">Shown in browser tab and search results.</span>
      </div>
      <div class="field">
        <label for="meta_description">Meta description</label>
        <textarea id="meta_description" name="meta_description" maxlength="320"><?= e($product['meta_description'] ?? $_POST['meta_description'] ?? '') ?></textarea>
      </div>
      <div class="field">
        <label for="meta_keywords">Meta keywords</label>
        <input id="meta_keywords" name="meta_keywords" value="<?= e($product['meta_keywords'] ?? $_POST['meta_keywords'] ?? '') ?>">
      </div>
    </div>
  </div>

  <div style="display:flex;gap:12px;margin-top:8px">
    <button class="btn btn-primary" type="submit"><?= $product ? 'Save changes' : 'Create product' ?></button>
    <a href="<?= e(BASE_URL) ?>/admin/products.php" class="btn btn-ghost">Cancel</a>
  </div>
</form>
<?php include __DIR__ . '/footer.php'; ?>
