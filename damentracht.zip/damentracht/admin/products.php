<?php
require_once __DIR__ . '/header.php';
$activeNav = 'products';

$search = trim($_GET['q'] ?? '');
if ($search) {
    $stmt = db()->prepare('SELECT p.*, c.name AS category_name FROM products p LEFT JOIN categories c ON c.id = p.category_id WHERE p.name LIKE ? ORDER BY p.created_at DESC');
    $stmt->execute(['%' . $search . '%']);
    $products = $stmt->fetchAll();
} else {
    $products = db()->query('SELECT p.*, c.name AS category_name FROM products p LEFT JOIN categories c ON c.id = p.category_id ORDER BY p.created_at DESC')->fetchAll();
}
?>
<form method="get" style="max-width:360px;margin-bottom:20px;display:flex;gap:8px">
  <input type="search" name="q" value="<?= e($search) ?>" placeholder="Search products…" style="flex:1;background:var(--bg-soft);border:1px solid var(--line);color:var(--ink);padding:10px 14px;border-radius:6px">
  <button class="btn btn-outline btn-sm" type="submit">Search</button>
</form>

<div class="admin-panel" style="padding:0">
  <table class="admin-table">
    <thead><tr><th>Image</th><th>Name</th><th>Category</th><th>Price</th><th>Stock</th><th>Status</th><th>Actions</th></tr></thead>
    <tbody>
      <?php foreach ($products as $p): ?>
      <tr>
        <td><img src="<?= e(product_image_url($p['image'])) ?>" alt="" class="thumb" onerror="this.onerror=null;this.src='<?= e(asset_url('images/placeholder.svg')) ?>';"></td>
        <td><?= e($p['name']) ?><br><span class="hint"><?= e($p['sku']) ?></span></td>
        <td><?= e($p['category_name'] ?? '—') ?></td>
        <td><?= e(money($p['sale_price'] ?? $p['price'])) ?></td>
        <td><?= (int)$p['stock'] ?></td>
        <td>
          <?php if ($p['is_active']): ?><span class="badge badge-green">Active</span><?php else: ?><span class="badge badge-red">Hidden</span><?php endif; ?>
          <?php if ($p['is_featured']): ?><span class="badge badge-amber" style="margin-left:4px">Featured</span><?php endif; ?>
        </td>
        <td class="actions">
          <a href="<?= e(BASE_URL) ?>/admin/product-edit.php?id=<?= e($p['slug']) ?>" class="btn btn-ghost btn-sm">Edit</a>
          <a href="<?= e(BASE_URL) ?>/admin/product-delete.php?id=<?= (int)$p['id'] ?>" class="del btn btn-ghost btn-sm" data-confirm="Delete this product? This cannot be undone.">Delete</a>
        </td>
      </tr>
      <?php endforeach; ?>
      <?php if (!$products): ?><tr><td colspan="7" style="text-align:center;color:var(--ink-mute);padding:40px">No products found.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>
<p style="margin-top:16px"><a href="<?= e(BASE_URL) ?>/admin/product-edit.php" class="btn btn-primary">+ Add new product</a></p>
<?php include __DIR__ . '/footer.php'; ?>
