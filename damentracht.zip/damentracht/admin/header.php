<?php
// Shared admin header. Expects $title and optional $activeNav.
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/auth.php';
require_admin();
$admin = current_admin();
$active = $activeNav ?? '';
$siteName = setting('site_name', 'Damentracht');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title><?= e($title ?? 'Admin') ?> — <?= e($siteName) ?> Admin</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Fraunces:wght@500;600&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= e(BASE_URL) ?>/assets/css/style.css">
</head>
<body class="admin-body">
<div class="admin-layout">
  <aside class="admin-sidebar">
    <div class="admin-brand">
      <span class="brand-name"><?= e($siteName) ?></span>
      <span class="brand-tag">Admin Panel</span>
    </div>
    <nav class="admin-nav" aria-label="Admin">
      <a href="<?= e(BASE_URL) ?>/admin/index.php" class="<?= $active === 'dashboard' ? 'active' : '' ?>">Dashboard</a>
      <a href="<?= e(BASE_URL) ?>/admin/products.php" class="<?= $active === 'products' ? 'active' : '' ?>">Products</a>
      <a href="<?= e(BASE_URL) ?>/admin/product-edit.php" class="<?= $active === 'product-new' ? 'active' : '' ?>">Add Product</a>
      <a href="<?= e(BASE_URL) ?>/admin/categories.php" class="<?= $active === 'categories' ? 'active' : '' ?>">Categories</a>
      <a href="<?= e(BASE_URL) ?>/admin/orders.php" class="<?= $active === 'orders' ? 'active' : '' ?>">Orders</a>
      <a href="<?= e(BASE_URL) ?>/admin/settings.php" class="<?= $active === 'settings' ? 'active' : '' ?>">Settings</a>
      <a href="<?= e(BASE_URL) ?>/admin/logout.php" style="margin-top:24px;color:var(--ink-mute)">Logout</a>
      <a href="<?= e(BASE_URL) ?>/index.php" style="color:var(--ink-mute)">← View site</a>
    </nav>
  </aside>
  <main class="admin-main">
    <div class="admin-topbar">
      <h1><?= e($title ?? 'Dashboard') ?></h1>
      <div class="user">Signed in as <?= e($admin['name'] ?? 'Admin') ?></div>
    </div>
