<?php
require_once __DIR__ . '/header.php';
$activeNav = 'orders';

$status = $_GET['status'] ?? '';
$valid = ['pending','processing','completed','cancelled'];
if ($status && in_array($status, $valid)) {
    $stmt = db()->prepare('SELECT * FROM orders WHERE status = ? ORDER BY created_at DESC');
    $stmt->execute([$status]);
} else {
    $orders = db()->query('SELECT * FROM orders ORDER BY created_at DESC')->fetchAll();
    $stmt = null;
}
$orders = $stmt ? $stmt->fetchAll() : $orders;
?>
<div style="margin-bottom:16px;display:flex;gap:8px;flex-wrap:wrap">
  <a href="<?= e(BASE_URL) ?>/admin/orders.php" class="btn btn-ghost btn-sm <?= !$status ? 'btn-outline' : '' ?>">All</a>
  <?php foreach ($valid as $s): ?>
    <a href="<?= e(BASE_URL) ?>/admin/orders.php?status=<?= $s ?>" class="btn btn-ghost btn-sm <?= $status===$s ? 'btn-outline' : '' ?>"><?= e(ucfirst($s)) ?></a>
  <?php endforeach; ?>
</div>
<div class="admin-panel" style="padding:0">
  <table class="admin-table">
    <thead><tr><th>#</th><th>Customer</th><th>Total</th><th>Payment</th><th>Status</th><th>Date</th><th></th></tr></thead>
    <tbody>
      <?php foreach ($orders as $o): ?>
      <tr>
        <td>#<?= (int)$o['id'] ?></td>
        <td><?= e($o['customer_name']) ?><br><span class="hint"><?= e($o['customer_email']) ?></span></td>
        <td><?= e(money($o['total_amount'])) ?></td>
        <td><?= e($o['payment_method']) ?></td>
        <td><span class="badge <?= $o['status']==='completed'?'badge-green':($o['status']==='pending'?'badge-amber':'badge-red') ?>"><?= e(ucfirst($o['status'])) ?></span></td>
        <td><?= e(date('d M Y, H:i', strtotime($o['created_at']))) ?></td>
        <td><a href="<?= e(BASE_URL) ?>/admin/order-view.php?id=<?= (int)$o['id'] ?>" class="btn btn-ghost btn-sm">View</a></td>
      </tr>
      <?php endforeach; ?>
      <?php if (!$orders): ?><tr><td colspan="7" style="text-align:center;color:var(--ink-mute);padding:30px">No orders found.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>
<?php include __DIR__ . '/footer.php'; ?>
