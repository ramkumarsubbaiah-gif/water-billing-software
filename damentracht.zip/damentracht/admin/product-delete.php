<?php
require_once __DIR__ . '/header.php';
$id = (int)($_GET['id'] ?? 0);
if (!$id) redirect(BASE_URL . '/admin/products.php');

$stmt = db()->prepare('SELECT image FROM products WHERE id = ?');
$stmt->execute([$id]);
$product = $stmt->fetch();
if (!$product) redirect(BASE_URL . '/admin/products.php');

// Delete image file
if ($product['image']) {
    $path = UPLOAD_DIR . '/' . $product['image'];
    if (is_file($path)) @unlink($path);
}

$stmt = db()->prepare('DELETE FROM products WHERE id = ?');
$stmt->execute([$id]);
redirect(BASE_URL . '/admin/products.php');
