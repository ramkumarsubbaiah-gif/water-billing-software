<?php
require_once __DIR__ . '/includes/functions.php';
$q = trim($_GET['q'] ?? '');
$products = $q ? get_products(['search' => $q, 'limit' => 60]) : [];
$page = [
    'title' => ($q ? 'Search: ' . $q : 'Search') . ' — Damentracht',
    'description' => 'Search products on Damentracht',
];
include __DIR__ . '/includes/header.php';
?>
<div class="container">
  <div class="page-head">
    <h1>Search</h1>
    <p>Find what you're looking for across our collections.</p>
  </div>
  <form class="search-box" method="get">
    <input type="search" name="q" value="<?= e($q) ?>" placeholder="Search products…" aria-label="Search">
    <button class="btn btn-primary" type="submit">Search</button>
  </form>
  <?php if ($q): ?>
    <p style="text-align:center;color:var(--ink-mute);margin-bottom:32px">
      <?= count($products) ?> result<?= count($products) === 1 ? '' : 's' ?> for "<?= e($q) ?>"
    </p>
  <?php endif; ?>
  <?php if ($products): ?>
  <div class="product-grid">
    <?php foreach ($products as $p): include __DIR__ . '/includes/product_card.php'; endforeach; ?>
  </div>
  <?php elseif ($q): ?>
  <div class="empty-state"><h3>No products found</h3><p>Try a different search term.</p></div>
  <?php endif; ?>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
