<?php
require_once __DIR__ . '/includes/functions.php';
if (session_status() === PHP_SESSION_NONE) session_start();

$items = cart_items();
$total = cart_total();
$error = '';
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $items) {
    $name    = trim($_POST['customer_name'] ?? '');
    $email   = trim($_POST['customer_email'] ?? '');
    $phone   = trim($_POST['customer_phone'] ?? '');
    $address = trim($_POST['shipping_address'] ?? '');
    $city    = trim($_POST['city'] ?? '');
    $state   = trim($_POST['state'] ?? '');
    $pincode = trim($_POST['pincode'] ?? '');
    $pay     = $_POST['payment_method'] ?? 'COD';
    $notes   = trim($_POST['notes'] ?? '');

    if (!$name || !$email || !$phone || !$address || !$city || !$state || !$pincode) {
        $error = 'Please fill in all required fields.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } else {
        try {
            $pdo = db();
            $pdo->beginTransaction();
            $stmt = $pdo->prepare(
                'INSERT INTO orders (customer_name, customer_email, customer_phone, shipping_address, city, state, pincode, payment_method, total_amount, status, notes)
                 VALUES (?,?,?,?,?,?,?,?,?, "pending", ?)'
            );
            $stmt->execute([$name, $email, $phone, $address, $city, $state, $pincode, $pay, $total, $notes]);
            $orderId = (int)$pdo->lastInsertId();

            $itemStmt = $pdo->prepare(
                'INSERT INTO order_items (order_id, product_id, product_name, price, quantity)
                 VALUES (?,?,?,?,?)'
            );
            foreach ($items as $it) {
                $itemStmt->execute([$orderId, $it['id'], $it['name'], $it['price'], $it['qty']]);
            }
            $pdo->commit();
            $_SESSION['cart'] = [];
            $success = true;
        } catch (Throwable $e) {
            if (isset($pdo) && $pdo->inTransaction()) $pdo->rollBack();
            $error = 'Could not place order. Please try again.';
        }
    }
}

$page = ['title' => 'Checkout — Damentracht', 'description' => 'Complete your order'];
include __DIR__ . '/includes/header.php';
?>
<div class="container">
  <nav class="breadcrumb"><a href="<?= e(BASE_URL) ?>/index.php">Home</a><span>/</span><a href="<?= e(BASE_URL) ?>/cart.php">Cart</a><span>/</span> Checkout</nav>
</div>
<section class="section" style="padding-top:0">
  <div class="container">
    <h1 style="margin-bottom:32px">Checkout</h1>
    <?php if ($success): ?>
      <div class="alert alert-success">Thank you! Your order has been placed. We'll contact you shortly to confirm.</div>
      <a class="btn btn-primary" href="<?= e(BASE_URL) ?>/index.php">Back to home</a>
    <?php elseif (!$items && !$success): ?>
      <div class="empty-state"><h3>Your cart is empty</h3><a class="btn btn-primary" href="<?= e(BASE_URL) ?>/index.php" style="margin-top:18px">Continue shopping</a></div>
    <?php else: ?>
      <?php if ($error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>
      <div class="checkout-grid">
        <form method="post" class="form-grid">
          <div class="field-row">
            <div class="field"><label for="customer_name">Full name *</label><input id="customer_name" name="customer_name" required value="<?= e($_POST['customer_name'] ?? '') ?>"></div>
            <div class="field"><label for="customer_phone">Phone *</label><input id="customer_phone" name="customer_phone" required value="<?= e($_POST['customer_phone'] ?? '') ?>"></div>
          </div>
          <div class="field"><label for="customer_email">Email *</label><input type="email" id="customer_email" name="customer_email" required value="<?= e($_POST['customer_email'] ?? '') ?>"></div>
          <div class="field"><label for="shipping_address">Shipping address *</label><textarea id="shipping_address" name="shipping_address" required><?= e($_POST['shipping_address'] ?? '') ?></textarea></div>
          <div class="field-row">
            <div class="field"><label for="city">City *</label><input id="city" name="city" required value="<?= e($_POST['city'] ?? '') ?>"></div>
            <div class="field"><label for="state">State *</label><input id="state" name="state" required value="<?= e($_POST['state'] ?? '') ?>"></div>
          </div>
          <div class="field"><label for="pincode">PIN code *</label><input id="pincode" name="pincode" required value="<?= e($_POST['pincode'] ?? '') ?>"></div>
          <div class="field">
            <label for="payment_method">Payment method</label>
            <select id="payment_method" name="payment_method">
              <option value="COD">Cash on Delivery</option>
              <option value="UPI">UPI (pay on confirmation)</option>
              <option value="Bank">Bank Transfer</option>
            </select>
          </div>
          <div class="field"><label for="notes">Order notes (optional)</label><textarea id="notes" name="notes" placeholder="Any delivery instructions?"><?= e($_POST['notes'] ?? '') ?></textarea></div>
          <button class="btn btn-primary btn-block" type="submit">Place order</button>
        </form>
        <aside class="summary-card">
          <h3>Order summary</h3>
          <?php foreach ($items as $it): ?>
          <div class="summary-row"><span><?= e($it['name']) ?> × <?= (int)$it['qty'] ?></span><span><?= e(money($it['subtotal'])) ?></span></div>
          <?php endforeach; ?>
          <div class="summary-row total"><span>Total</span><span class="price-now"><?= e(money($total)) ?></span></div>
        </aside>
      </div>
    <?php endif; ?>
  </div>
</section>
<?php include __DIR__ . '/includes/footer.php'; ?>
