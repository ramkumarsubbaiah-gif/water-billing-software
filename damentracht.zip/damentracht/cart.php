<?php
require_once __DIR__ . '/includes/functions.php';
if (session_status() === PHP_SESSION_NONE) session_start();

// Handle AJAX actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    $action = $_POST['action'] ?? '';
    $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
    $qty = isset($_POST['qty']) ? max(1, (int)$_POST['qty']) : 1;

    if (!isset($_SESSION['cart'])) $_SESSION['cart'] = [];

    switch ($action) {
        case 'add':
            if ($id > 0) {
                $_SESSION['cart'][$id] = ($_SESSION['cart'][$id] ?? 0) + $qty;
                echo json_encode(['ok' => true, 'count' => cart_count(), 'message' => 'Added to cart']);
                exit;
            }
            break;
        case 'update':
            if ($id > 0) {
                if ($qty > 0) $_SESSION['cart'][$id] = $qty;
                else unset($_SESSION['cart'][$id]);
                echo json_encode(['ok' => true, 'count' => cart_count()]);
                exit;
            }
            break;
        case 'remove':
            unset($_SESSION['cart'][$id]);
            echo json_encode(['ok' => true, 'count' => cart_count()]);
            exit;
        case 'clear':
            $_SESSION['cart'] = [];
            echo json_encode(['ok' => true, 'count' => 0]);
            exit;
    }
    echo json_encode(['ok' => false, 'message' => 'Invalid action']);
    exit;
}

$items = cart_items();
$total = cart_total();
$page = ['title' => 'Cart — Damentracht', 'description' => 'Your shopping cart'];
include __DIR__ . '/includes/header.php';
?>
<div class="container">
  <nav class="breadcrumb"><a href="<?= e(BASE_URL) ?>/index.php">Home</a><span>/</span> Cart</nav>
</div>
<section class="section" style="padding-top:0">
  <div class="container">
    <h1 style="margin-bottom:32px">Your cart</h1>
    <?php if (!$items): ?>
    <div class="empty-state">
      <h3>Your cart is empty</h3>
      <p>Looks like you haven't added anything yet.</p>
      <a class="btn btn-primary" href="<?= e(BASE_URL) ?>/index.php" style="margin-top:18px">Continue shopping</a>
    </div>
    <?php else: ?>
    <div class="cart-layout" data-cart-form>
      <div class="cart-list">
        <?php foreach ($items as $it): ?>
        <div class="cart-row">
          <a href="<?= e(BASE_URL) ?>/product.php?slug=<?= e($it['slug']) ?>"><img src="<?= e(product_image_url($it['image'])) ?>" alt="<?= e($it['name']) ?>" onerror="this.onerror=null;this.src='<?= e(asset_url('images/placeholder.svg')) ?>';"></a>
          <div>
            <a href="<?= e(BASE_URL) ?>/product.php?slug=<?= e($it['slug']) ?>"><div class="name"><?= e($it['name']) ?></div></a>
            <div class="meta"><?= e(money($it['price'])) ?> each</div>
            <div class="qty-control" style="margin-top:10px;width:fit-content">
              <button type="button" data-qty-minus aria-label="Decrease">−</button>
              <input type="number" value="<?= (int)$it['qty'] ?>" min="1" max="99" data-cart-qty="<?= e($it['id']) ?>" aria-label="Quantity">
              <button type="button" data-qty-plus aria-label="Increase">+</button>
            </div>
          </div>
          <div style="text-align:right">
            <div class="price-now"><?= e(money($it['subtotal'])) ?></div>
            <a href="#" class="remove" data-cart-remove="<?= e($it['id']) ?>" style="display:inline-block;margin-top:8px">Remove</a>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
      <aside class="summary-card">
        <h3>Order summary</h3>
        <div class="summary-row"><span>Subtotal</span><span><?= e(money($total)) ?></span></div>
        <div class="summary-row"><span>Shipping</span><span>Calculated at checkout</span></div>
        <div class="summary-row total"><span>Total</span><span class="price-now"><?= e(money($total)) ?></span></div>
        <a class="btn btn-primary btn-block" href="<?= e(BASE_URL) ?>/checkout.php" style="margin-top:16px">Proceed to checkout</a>
        <a class="btn btn-ghost btn-block" href="<?= e(BASE_URL) ?>/index.php" style="margin-top:8px">Continue shopping</a>
      </aside>
    </div>
    <?php endif; ?>
  </div>
</section>
<?php include __DIR__ . '/includes/footer.php'; ?>
